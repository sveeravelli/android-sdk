var classcom_1_1visualon_1_1_v_o_o_s_m_p_streaming_downloader_1_1_v_o_o_s_m_p_streaming_downloader_init_param =
[
    [ "VOOSMPStreamingDownloaderInitParam", "d3/de6/classcom_1_1visualon_1_1_v_o_o_s_m_p_streaming_downloader_1_1_v_o_o_s_m_p_streaming_downloader_init_param.html#a911b79e1d839e74c8e6187510c9f7f8d", null ],
    [ "getContext", "d3/de6/classcom_1_1visualon_1_1_v_o_o_s_m_p_streaming_downloader_1_1_v_o_o_s_m_p_streaming_downloader_init_param.html#a9bb5c026dd0b0403c7d7040a93d32f17", null ],
    [ "getLibraryPath", "d3/de6/classcom_1_1visualon_1_1_v_o_o_s_m_p_streaming_downloader_1_1_v_o_o_s_m_p_streaming_downloader_init_param.html#a5f09f72eabb2ea186f67820b90789b78", null ],
    [ "setContext", "d3/de6/classcom_1_1visualon_1_1_v_o_o_s_m_p_streaming_downloader_1_1_v_o_o_s_m_p_streaming_downloader_init_param.html#ac9e849ce6ed0428223b3adacdc3268f4", null ],
    [ "setLibraryPath", "d3/de6/classcom_1_1visualon_1_1_v_o_o_s_m_p_streaming_downloader_1_1_v_o_o_s_m_p_streaming_downloader_init_param.html#a0ade4d0eaf096bb7953ff98b61dfe932", null ]
];