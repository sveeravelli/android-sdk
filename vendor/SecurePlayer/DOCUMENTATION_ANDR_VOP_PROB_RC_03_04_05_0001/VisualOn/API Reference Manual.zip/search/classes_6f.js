var searchData=
[
  ['onhdmiconnectionchangelistener',['onHDMIConnectionChangeListener',['../db/d71/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i_1_1on_h_d_m_i_connection_change_listener.html',1,'com::visualon::OSMPPlayer::VOCommonPlayerHDMI']]]
];
