/********************************************************
*                                                       *
* VisualOn(R) OnStream(R) MediaPlayer+ Integration Labs *
*                for Android Platforms                  *
*                                                       *
********************************************************/

Overview
--------

These integration labs provide working examples to accompany the OnStream MediaPlayer+ Player SDK Integration Guide for Android Platforms. The labs focus on individual integration topics; for an example of a fully integrated SDK client, refer to the SamplePlayer project.

Lab Descriptions
----------------

Lab 1  : Basic SDK Client (player) that plays an URL or a local media file without any user input
Lab 2  : Basic SDK Client (player) with a shared pause/play button. Based on Lab 1
Lab 3a : Basic SDK Client (player) with +/-5s seek buttons. Based on Lab 1
Lab 3b : Basic SDK Client (player) with seekbar control. Based on Lab 1
Lab 4  : Basic SDK Client (player) with channel switching. Based on Lab 1
Lab 5a : Basic SDK Client (player) with CC/subtitles rendering. Based on Lab 1
Lab 6a : Basic SDK Client (player) with video track switching. Based on Lab 1
Lab 7  : Basic SDK Client (player) with suspend/resume. Based on Lab 1

Project Setup
-------------

The integration labs require installation of the SDK and license file. Refer to the OnStream MediaPlayer+ SDK Project Setup for Android Platforms manual. A temporary license file is included with the SamplePlayer project; it may be used for the integration labs as well. Please contact VisualOn support if you require a new temporary license.

Important Note
---------------

1. For Lab5a: Closed Captions will not display since the default bipbop link included doesn't contain any.
 To have captions display, valid test streams and subtitle files must be added to player.java before 
building the application.
