/******************************************************
*                                                     *
* VisualOn OnStream(R) MediaPlayer+ Integration Labs  *
*               for Android Platforms.                *
*                  Note for Lab5a                     *
*                                                     *
******************************************************/

Lab Description
----------------

Lab 5a : Basic SDK Client (player) with CC/subtitles rendering. Based on Lab 2.

Important Note
---------------

1. Closed Captions won't display since the default bipbop link included doesn't contain any.
   To have Captions display, valid test streams and subtitle files must be added to player.java 
   before building the application.
