
/************************************************************************
                       VisualOn Proprietary
Copyright (c) 2013, VisualOn Incorporated. All Rights Reserved

VisualOn, Inc., 4675 Stevens Creek Blvd, Santa Clara, CA 95051, USA

All data and information contained in or disclosed by this document are
confidential and proprietary information of VisualOn, and all rights
therein are expressly reserved. By accepting this material, the
recipient agrees that this material and the information contained
therein are held in confidence and in trust. The material may only be
used and/or disclosed as authorized in a license agreement controlling
such use and disclosure.
 ************************************************************************/
/*
 * Integration Lab #6a
 * Implements a basic SDK Client (player) that plays a URL or a local media file with video track switching.
 * Based on Integration Lab #1
 */

package com.visualon.LabPlayer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.visualon.OSMPPlayer.VOCommonPlayer;
import com.visualon.OSMPPlayer.VOCommonPlayerAssetSelection.VOOSMPAssetIndex;
import com.visualon.OSMPPlayer.VOCommonPlayerAssetSelection.VOOSMPAssetProperty;
import com.visualon.OSMPPlayer.VOOSMPInitParam;
import com.visualon.OSMPPlayer.VOOSMPOpenParam;
import com.visualon.OSMPPlayer.VOCommonPlayerListener;
import com.visualon.OSMPPlayer.VOOSMPType.*;

import com.visualon.OSMPPlayerImpl.*;

// Activity implements SurfaceHolder.Callback and VOCommonPlayerListener
public class Player extends Activity implements SurfaceHolder.Callback 
{
    
    private static final String TAG = "Lab6a Player"; // Tag for VOLog messages
    
    private SurfaceView m_svMain; // Drawing surface (must be passed to SDK)
    private VOCommonPlayer m_sdkPlayer = null; // SDK player
    
    // Media controls and User interface
    private TextView m_tvCurrentVideo;                        // Current position
    private Button m_bNextVideo; // Advance video button
    private Button m_bGetVideo; // Get video track info button
    
    private String m_strVideoPath = ""; // URL or file path to media source
    
    private int                  m_nVideoWidth        = 0;               // Video width
    private int                  m_nVideoHeight       = 0;               // video height

    // Called when the activity is first created
    // Used to initialize the SDK client
    public void onCreate(Bundle savedInstanceState) {

	super.onCreate(savedInstanceState);
	Log.v(TAG, "Player onCreate");

	// Screen always on
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
			     WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	
	setContentView(R.layout.player); // R.layout.player refers to the
	// player.xml file located in the
	// res/layout folder
	
	// SDK client initialization
	// Define your playback URL/local media file here
	m_strVideoPath = "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"; 
	//m_strVideoPath = "/sdcard/test.mp4"; // Use local file to test pause/play and seek functions
	
	getWindow().setFormat(PixelFormat.UNKNOWN);
	
	// Find SurfaceView and Surface holder from the layout
	m_svMain = (SurfaceView) findViewById(R.id.svMain);
	// Add a Callback for this holder
	m_svMain.getHolder().addCallback(this);
	// Set pixel format to RGB32
	m_svMain.getHolder().setFormat(PixelFormat.RGBA_8888);

	// Activate listener for Next Video
	m_bNextVideo = (Button) findViewById(R.id.bNextVideo);
	m_bNextVideo.setOnClickListener(new Button.OnClickListener() {
		public void onClick(View view) {
		    nextVideo();
		}
	    });
		
	// Activate listener for External Subtitle Enable/Disable button
	m_bGetVideo = (Button) findViewById(R.id.bGetVideo);
	m_bGetVideo.setOnClickListener(new Button.OnClickListener() {
		public void onClick(View view) {
		    getVideoList();
		}
	    });

	m_tvCurrentVideo = (TextView)findViewById(R.id.tvCurrentVideo);
		
	// Copy license file and device capability file
	copyfile(this, "voVidDec.dat", "voVidDec.dat");
	copyfile(this, "cap.xml", "cap.xml");
    }
    
    // Notify SDK on Surface Change
    public void surfaceChanged(SurfaceHolder surfaceholder, int format, int w,
			       int h) {
	
	Log.i(TAG, "Surface Changed");
	if (m_sdkPlayer != null)
	    m_sdkPlayer.setSurfaceChangeFinished();
    }

    // Notify SDK on Surface Creation
    // Used to initialize the SDK and start playback
    public void surfaceCreated(SurfaceHolder surfaceholder) {
	
	Log.i(TAG, "Surface Created");
	
	if ((m_strVideoPath == null) || (m_strVideoPath.trim().length() <= 0)) {
	    return;
	}
	
	if (m_sdkPlayer != null)
	    return;
	
	// Initialize the SDK
	VO_OSMP_RETURN_CODE nRet;
	
	m_sdkPlayer = new VOCommonPlayerImpl();

	m_svMain.getHolder().setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

	// Retrieve location of libraries
	String apkPath = getUserPath(this) + "/lib/";
	String cfgPath = getUserPath(this) + "/";
	
	// SDK player engine type
	VO_OSMP_PLAYER_ENGINE eEngineType = VO_OSMP_PLAYER_ENGINE.VO_OSMP_VOME2_PLAYER;
	
	
	VOOSMPInitParam init = new VOOSMPInitParam();
	init.setContext(this);
	init.setLibraryPath(apkPath);

		
	// Initialize SDK player
	nRet = m_sdkPlayer.init(eEngineType, init);
	
	// Set view
	m_sdkPlayer.setView(m_svMain);

	// Set surface view size
	DisplayMetrics dm = new DisplayMetrics();
	getWindowManager().getDefaultDisplay().getMetrics(dm);
	m_sdkPlayer.setViewSize(dm.widthPixels, dm.heightPixels);
	
	// Register SDK event listener
	m_sdkPlayer.setOnEventListener(m_listenerEvent);
	
	if (nRet == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE) {
	    Log.v(TAG, "MediaPlayer is created.");
	} else {
	    onError(m_sdkPlayer, nRet.getValue(), 0);
	    return;
	}
	
	// Set device capability file location
	String capFile = cfgPath + "cap.xml";
	m_sdkPlayer.setDeviceCapabilityByFile(capFile);
	// Set license file location
	m_sdkPlayer.setLicenseFilePath(cfgPath);
	
	//m_sdkPlayer.enableDeblock(false);
	
	// Start playing the 
	// First open the media source
	// Auto-detect source format		
	VO_OSMP_SRC_FORMAT format = VO_OSMP_SRC_FORMAT.VO_OSMP_SRC_AUTO_DETECT;
	
	// Set source flag to synchronous - Using Sync Open
	//VO_OSMP_SRC_FLAG eSourceFlag;
	//eSourceFlag = VO_OSMP_SRC_FLAG.VO_OSMP_FLAG_SRC_OPEN_SYNC;
	
	// Set source flag to Asynchronous Open - Using Async Open
	VO_OSMP_SRC_FLAG eSourceFlag;
	eSourceFlag = VO_OSMP_SRC_FLAG.VO_OSMP_FLAG_SRC_OPEN_ASYNC;

        VOOSMPOpenParam openParam = new VOOSMPOpenParam();
      	openParam.setDecoderType(VO_OSMP_DECODER_TYPE.VO_OSMP_DEC_VIDEO_SW.getValue() | VO_OSMP_DECODER_TYPE.VO_OSMP_DEC_AUDIO_SW.getValue());
        
	// Open media source
        nRet = m_sdkPlayer.open(m_strVideoPath, eSourceFlag, format, openParam);
        
	if (nRet == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE) {
	    Log.v(TAG, "MediaPlayer is Opened (Async Open).");
	} else {
	    onError(m_sdkPlayer, nRet.getValue(), 0);
	    return;
	}
        
	/* Following block needed here only for SYNC_OPEN
	// Start (play) media pipeline
	nRet = m_sdkPlayer.start();

	if (nRet == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE) {
			Log.v(TAG, "MediaPlayer run.");
			} else {
			onError(m_sdkPlayer, nRet.getValue(), 0);
			}
	*/
    }
    
    // Notify SDK on Surface Destroyed
    public void surfaceDestroyed(SurfaceHolder surfaceholder) {
	
	Log.i(TAG, "Surface Destroyed");
	
	if (m_sdkPlayer != null) {
	    m_sdkPlayer.stop();
	    m_sdkPlayer.close();
	    m_sdkPlayer.destroy();
	    m_sdkPlayer = null;
	    Log.v(TAG, "MediaPlayer is released.");
	}
    }

    // Display error messages and stop player
    public boolean onError(VOCommonPlayer mp, int what, int extra) {
	
	Log.v(TAG, "Error message, what is " + what + " extra is " + extra);
	String errStr = getString(R.string.str_ErrPlay_Message)
	    + "\nError code is " + Integer.toHexString(what);
	
	// Dialog to display error message; stop player and exit on Back key or
	// OK
	AlertDialog ad = new AlertDialog.Builder(Player.this)
	    .setIcon(R.drawable.icon).setTitle(R.string.str_ErrPlay_Title)
	    .setMessage(errStr).setOnKeyListener(new OnKeyListener() {
		    
		    public boolean onKey(DialogInterface arg0, int arg1,
					 KeyEvent arg2) {
			
			if (arg1 == KeyEvent.KEYCODE_BACK) {
			    if (m_sdkPlayer != null) {
				m_sdkPlayer.stop();
				m_sdkPlayer.close();
				m_sdkPlayer.destroy();
				m_sdkPlayer = null;
				Log.v(TAG, "MediaPlayer is released.");
			    }
			}
			return false;
		    }
		}).setPositiveButton(R.string.str_OK, new OnClickListener() {
			public void onClick(DialogInterface a0, int a1) {
			    if (m_sdkPlayer != null) {
				m_sdkPlayer.stop();
				m_sdkPlayer.close();
				m_sdkPlayer.destroy();
				m_sdkPlayer = null;
				Log.v(TAG, "MediaPlayer is released.");
			    }
			}
		    }).create();
	ad.show();
	return true;
    }
    
    // Get list of video tracks
    public void getVideoList()
    {
	ArrayList<String> lstString = new ArrayList<String>();
	// Get number of video tracks from SDK
	int nVideoCount = m_sdkPlayer.getVideoCount();
        Log.v(TAG, "MediaPlayer video count: " + Integer.toString(nVideoCount));
        
        // Populate list with track descriptions
        for (int nAssetIndex = 0; nAssetIndex < nVideoCount; nAssetIndex++) {
	    // Get track properties
            VOOSMPAssetProperty propImpl =m_sdkPlayer.getVideoProperty(nAssetIndex);
           
            String strDescription = "";
            int nPropertyCount = propImpl.getPropertyCount();
            //Log.v(TAG, "MediaPlayer video track has " + Integer.toString(nPropertyCount) + " properties.");
            boolean bPropertyDescription = false;
            for (int i = 0; i < nPropertyCount; i++) {
            	// Look for the description
            	String strPropertyKey = propImpl.getKey(i);
            	//Log.v(TAG, "MediaPlayer video track property " + Integer.toString(i) + " key is " + strPropertyKey + ".");
                if (strPropertyKey.equals("description")) {
		    bPropertyDescription = true;
		    strDescription = (String) propImpl.getValue(i);
                }
            }

            if (bPropertyDescription == false) {
            	// If the track has no description, then give it a default one
                strDescription = "Track " + Integer.toString(nAssetIndex);
            } 
            // Add description to the list
            lstString.add(strDescription);
	    
        }
        if (lstString.size() != 0) {
	    // Dialog to display track information
	    String msgStr = Integer.toString(nVideoCount) + " video tracks found:\n";
	    for (int i = 0; i < lstString.size(); i++) {
		msgStr += "Track " + Integer.toString(i) + ": " + lstString.get(i) + "\n";
	    }
	    AlertDialog ad = new AlertDialog.Builder(Player.this)
		.setIcon(R.drawable.icon).setTitle("Video")
		.setMessage(msgStr).setPositiveButton(R.string.str_OK, new OnClickListener() {
			public void onClick(DialogInterface a0, int a1) {return;}
		    }).create();
	    ad.show();
	    return;
        }
    }
	
    // Advance the video track
    public void nextVideo() {
	if (m_sdkPlayer == null) { 
	    return; 
	}
	VO_OSMP_RETURN_CODE nRet;
	// Get number of video tracks from SDK
	int nVideoCount = m_sdkPlayer.getVideoCount();
	
	// Get current video index
	VOOSMPAssetIndex assetIndex= m_sdkPlayer.getPlayingAsset();
	int nCurrentIndex = assetIndex.getVideoIndex();
	int nNewIndex = nCurrentIndex;
	
	// Find next available track
	boolean bFoundNextAvailableTrack = false;
	// Loop until next track is found; or until you have reached the original track
	int i = 0;
	while ((!bFoundNextAvailableTrack) && (i < nVideoCount-1)) {
	    i++;
	    nNewIndex++;
	    if (nNewIndex >= nVideoCount) {
		// Loop to first track
		nNewIndex = 0;
	    }
	    if ((m_sdkPlayer.isVideoAvailable(nNewIndex))) {
		// Track is available
		bFoundNextAvailableTrack = true;
	    }
	}
		
	if (!bFoundNextAvailableTrack) {
	    // If there is only one track, nothing to do
	    String msgStr = "No other tracks available. Nothing to do.";
	    AlertDialog ad = new AlertDialog.Builder(Player.this)
		.setIcon(R.drawable.icon).setTitle("Nothing to do")
		.setMessage(msgStr).setPositiveButton(R.string.str_OK, new OnClickListener() {
			public void onClick(DialogInterface a0, int a1) {return;}
		    }).create();
	    ad.show();
	    return;
	}
		
	// Select new video track
	nRet = m_sdkPlayer.selectVideo(nNewIndex);
	if (nRet == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE) {
	    Log.v(TAG, "MediaPlayer video track " + Integer.toString(nNewIndex) + " selected.");
	} else {
	    onError(m_sdkPlayer, nRet.getValue(), 0);
	}
	
	// Commit selection
	nRet = m_sdkPlayer.commitSelection();
	if (nRet == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE) {
	    Log.v(TAG, "MediaPlayer video track " + Integer.toString(nNewIndex) + " selection committed.");
	} else {
	    onError(m_sdkPlayer, nRet.getValue(), 0);
	}
	// Update text view
	m_tvCurrentVideo.setText("Video Changed: Track " + Integer.toString(nNewIndex));
    }
    
    private VOCommonPlayerListener m_listenerEvent = new VOCommonPlayerListener() {
	    /* SDK event handling */
	    @SuppressWarnings("incomplete-switch")
	    public VO_OSMP_RETURN_CODE onVOEvent(VO_OSMP_CB_EVENT_ID nID, int nParam1, int nParam2, Object obj) {
		switch(nID) { 
		    
		case VO_OSMP_CB_ERROR:  
		case VO_OSMP_SRC_CB_CONNECTION_FAIL:
		case VO_OSMP_SRC_CB_DOWNLOAD_FAIL:
		case VO_OSMP_SRC_CB_DRM_FAIL:
		case VO_OSMP_SRC_CB_PLAYLIST_PARSE_ERR:
		case VO_OSMP_SRC_CB_CONNECTION_REJECTED:
		case VO_OSMP_SRC_CB_DRM_NOT_SECURE:
		case VO_OSMP_SRC_CB_DRM_AV_OUT_FAIL: 
		case VO_OSMP_CB_LICENSE_FAIL: {  // Error
		    // Display error dialog and stop player
		    onError(m_sdkPlayer, nID.getValue(), 0);
		    break;
		}
		    
		case VO_OSMP_SRC_CB_OPEN_FINISHED: {
		    Log.v(TAG, "Async Open Finished...");
	            
		    if (nParam1 == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE.getValue())  {
			Log.v(TAG, "MediaPlayer is opened (async open).");
	                
			VO_OSMP_RETURN_CODE nRet;
			
			// Start (play) media pipeline 
			nRet = m_sdkPlayer.start();
			
			if (nRet == VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE) {
			    Log.v(TAG, "MediaPlayer run.");
			} else {
			    onError(m_sdkPlayer, nRet.getValue(), 0);
			}
	   	
		    }else {
			onError(m_sdkPlayer, nParam1, 0);
		    }
	            
		    break;
		}
		    
		case VO_OSMP_CB_PLAY_COMPLETE: {
		    if (m_sdkPlayer != null) {
			m_sdkPlayer.stop();
			m_sdkPlayer.close();
			m_sdkPlayer.destroy();
			m_sdkPlayer = null;
			//  				this.finish();
			Log.v(TAG, "MediaPlayer is released.");
		    }
		    break;
		}
		case VO_OSMP_CB_VIDEO_SIZE_CHANGED: {   // Video size changed
		    m_nVideoWidth = nParam1;
		    m_nVideoHeight = nParam2;
		    break;
		} 		
		}
	        return VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE;       
	    }	
	    
	    //@Override
	    public VO_OSMP_RETURN_CODE onVOSyncEvent(VO_OSMP_CB_SYNC_EVENT_ID arg0,
						     int arg1, int arg2, Object arg3) {
		// TODO Auto-generated method stub
		return VO_OSMP_RETURN_CODE.VO_OSMP_ERR_NONE;
	    }
	};
    
    // Get user path for Jelly Bean 4.2
    public static String getUserPath(Context context) {
	PackageManager m = context.getPackageManager();
	String path = context.getPackageName();
	String userPath = "/data/data/" + path;
	try {
	    PackageInfo p = m.getPackageInfo(path, 0);
	    userPath = p.applicationInfo.dataDir;
	} catch (NameNotFoundException e) {
	}
	
	return userPath;
    }
    
    // Copy file from Assets directory to destination
    // Used for licenses and processor-specific configurations
    private static void copyfile(Context context, String filename,
				 String desName) {
	try {
	    InputStream InputStreamis = context.getAssets().open(filename);
	    File desFile = new File(getUserPath(context) + "/" + desName);
	    desFile.createNewFile();
	    FileOutputStream fos = new FileOutputStream(desFile);
	    int bytesRead;
	    byte[] buf = new byte[4 * 1024]; // 4K buffer
	    
	    while ((bytesRead = InputStreamis.read(buf)) != -1) {
		fos.write(buf, 0, bytesRead);
	    }
	    fos.flush();
	    fos.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }
}
