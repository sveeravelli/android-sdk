var interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle =
[
    [ "enableSubtitle", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a9963d98440a67133dcaca4631d7aef08", null ],
    [ "previewSubtitle", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a419754f554de4e3972cb2c2d0be3ee0f", null ],
    [ "resetSubtitleParameter", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a1ae12c1fef57f520f6f8480ae0933dda", null ],
    [ "setSubtitleFontBackgroundColor", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#ae4b085873c47fd9b9ae669b7ddeb5683", null ],
    [ "setSubtitleFontBackgroundOpacity", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a3e9cff671d114943d90516fa9142bd48", null ],
    [ "setSubtitleFontBold", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#ad516c0858b6cc3c9dc1ee3d5fc49265c", null ],
    [ "setSubtitleFontColor", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a6d973c0dae7b4089d38470f5eeac533d", null ],
    [ "setSubtitleFontEdgeColor", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a5867788ea79d51f6db367fbb710f6d23", null ],
    [ "setSubtitleFontEdgeOpacity", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a35d29d723e4344b879d49a5011cfb217", null ],
    [ "setSubtitleFontEdgeType", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#af043d95f02d31d97068751a9c756620f", null ],
    [ "setSubtitleFontItalic", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#aee2e4757fadec21dfb4a1d935dbcc72b", null ],
    [ "setSubtitleFontName", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a0faa1087681e9295fe05934370c3c2c6", null ],
    [ "setSubtitleFontOpacity", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a6e8d54859b7a511abcf836852a90a42a", null ],
    [ "setSubtitleFontSizeScale", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#ae7fae6bea9731c656814292d1beca89a", null ],
    [ "setSubtitleFontUnderline", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a663194c3c4af5256a99b0909ef376f05", null ],
    [ "setSubtitlePath", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a7b8a966a482a2fdce5835414cd96d28e", null ],
    [ "setSubtitleTypeface", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a4fbaebdc7da941f21da55adb5c00ed6e", null ],
    [ "setSubtitleWindowBackgroundColor", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#a30d6da1a55c658c7933d02a438776437", null ],
    [ "setSubtitleWindowBackgroundOpacity", "d4/d17/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_subtitle.html#ae403f1c12704eb512302d5650fcb322b", null ]
];