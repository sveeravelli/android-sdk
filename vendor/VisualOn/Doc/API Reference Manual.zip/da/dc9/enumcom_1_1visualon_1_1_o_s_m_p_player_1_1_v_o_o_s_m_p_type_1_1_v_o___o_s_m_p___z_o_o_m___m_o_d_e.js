var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e =
[
    [ "VO_OSMP_ZOOM_MODE", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#a77211b304860ba2d5ce00bb971e52038", null ],
    [ "getValue", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#a94a05381538209ab8f73b7082bbde9fc", null ],
    [ "valueOf", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#a2fb4b80e5193534aedfc558e24d17ddc", null ],
    [ "VO_OSMP_ZOOM_FITWINDOW", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#ac5483ea55891ecc80c57227fca08bbc3", null ],
    [ "VO_OSMP_ZOOM_LETTERBOX", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#a03afe53cd44b601c5c326b1674300d2c", null ],
    [ "VO_OSMP_ZOOM_MAX", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#a1f29dc11c80f964623e9e438a50c323e", null ],
    [ "VO_OSMP_ZOOM_ORIGINAL", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#aa7307cc11e10a5a87324b2777d3ebc51", null ],
    [ "VO_OSMP_ZOOM_PANSCAN", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#aed91e4248d25316ce2e445c1bec7294e", null ],
    [ "VO_OSMP_ZOOM_ZOOMIN", "da/dc9/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___z_o_o_m___m_o_d_e.html#a7cf4eaccb694a0cdebfed0bfa38275a1", null ]
];