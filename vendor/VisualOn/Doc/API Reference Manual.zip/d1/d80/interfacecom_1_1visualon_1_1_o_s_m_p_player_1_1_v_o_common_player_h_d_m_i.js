var interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i =
[
    [ "onHDMIConnectionChangeListener", "db/d71/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i_1_1on_h_d_m_i_connection_change_listener.html", "db/d71/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i_1_1on_h_d_m_i_connection_change_listener" ],
    [ "VO_OSMP_HDMI_CONNECTION_STATUS", "d8/d99/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i_1_1_v_o___o_s_m_p___h_d_m_i37095a8ca246bcd05af9c1e76fcc13e9.html", "d8/d99/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i_1_1_v_o___o_s_m_p___h_d_m_i37095a8ca246bcd05af9c1e76fcc13e9" ],
    [ "enableHDMIDetection", "d1/d80/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i.html#a8c08f29c57de0f0401a26bec55b7ce7b", null ],
    [ "getHDMIStatus", "d1/d80/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i.html#a9f79cdb87ed36e52f74645d9f4fcb3ec", null ],
    [ "isHDMIDetectionSupported", "d1/d80/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i.html#a499eaadfb137bf3567e712803b4432e3", null ],
    [ "setOnHDMIConnectionChangeListener", "d1/d80/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_h_d_m_i.html#a42caf13aee141d4780b79d0236b8d36c", null ]
];