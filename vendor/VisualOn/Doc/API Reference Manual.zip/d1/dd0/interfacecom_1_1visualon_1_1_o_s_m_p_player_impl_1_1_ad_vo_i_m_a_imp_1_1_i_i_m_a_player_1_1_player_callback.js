var interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback =
[
    [ "onCompleted", "d1/dd0/interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback.html#a9474b719dc64f18a6509aebe68243b8a", null ],
    [ "onError", "d1/dd0/interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback.html#a3c41d5a509e0dc4ca5ffc2503d767a86", null ],
    [ "onPause", "d1/dd0/interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback.html#ab619b436aad4be37adf874b7c3b50e04", null ],
    [ "onPlay", "d1/dd0/interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback.html#a39ddd3b95f991db87c3fde2b82bffc58", null ],
    [ "onResume", "d1/dd0/interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback.html#aa77417cbd5ce64ed9d9eb8a6b58325c6", null ]
];