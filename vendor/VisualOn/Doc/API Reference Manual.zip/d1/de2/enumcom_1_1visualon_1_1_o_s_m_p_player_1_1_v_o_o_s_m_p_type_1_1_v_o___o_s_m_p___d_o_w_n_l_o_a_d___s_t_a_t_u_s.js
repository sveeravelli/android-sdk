var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s =
[
    [ "VO_OSMP_DOWNLOAD_STATUS", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#aeef0457a3200a30d128ff1f4de7435df", null ],
    [ "getValue", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#a74e526fd866ba74c004213d602c69bfc", null ],
    [ "valueOf", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#a761a310cf6acb495561fc42a80ca9999", null ],
    [ "VO_OSMP_DOWNLOAD_MAX", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#af823fbcf2011b0a94d4fd87506022de0", null ],
    [ "VO_OSMP_DOWNLOAD_PROGRESS", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#ad46f65475b7cf8d24fb033438dad3c46", null ],
    [ "VO_OSMP_DOWNLOAD_STALL", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#a23f6036b2264cb0d483828230b873b1f", null ],
    [ "VO_OSMP_DOWNLOAD_SUSPEND", "d1/de2/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___d_o_w_n_l_o_a_d___s_t_a_t_u_s.html#a4028fdef2f688c4463afcb13a367d55f", null ]
];