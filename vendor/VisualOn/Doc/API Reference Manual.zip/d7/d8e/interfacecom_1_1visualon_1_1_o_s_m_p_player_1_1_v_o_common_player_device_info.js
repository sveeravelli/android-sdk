var interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info =
[
    [ "VO_OSMP_DEVICE_INFO_OS_TYPE", "d2/d01/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info_1_1_v_o___o_s_m_p___d_ede77238e7d8db4e6c2107a5280703866.html", "d2/d01/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info_1_1_v_o___o_s_m_p___d_ede77238e7d8db4e6c2107a5280703866" ],
    [ "getDeviceModel", "d7/d8e/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info.html#a9d6b40005ec80e2976736427aafe996b", null ],
    [ "getMaxCPUFrequency", "d7/d8e/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info.html#ab786129b9af6d943afdc73f9d12b1a1e", null ],
    [ "getNumberOfCores", "d7/d8e/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info.html#ae36f00a7d99a82a8049407da303a356d", null ],
    [ "getOSType", "d7/d8e/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info.html#a2bf35ae24e0fdeb45f836000d54f73bb", null ],
    [ "getOSVersion", "d7/d8e/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info.html#ac9a86f54372e0012495447fdedeb8dfd", null ],
    [ "hasNeon", "d7/d8e/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_device_info.html#a094e0dec0c12545e7a7c9994049c65d6", null ]
];