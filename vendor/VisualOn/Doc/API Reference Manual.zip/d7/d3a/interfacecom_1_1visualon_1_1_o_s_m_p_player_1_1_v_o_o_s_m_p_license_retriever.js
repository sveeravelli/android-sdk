var interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever =
[
    [ "acquireLicense", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#a3de016dab1eff76a1ab3b0e65ec30b5e", null ],
    [ "getErrorCode", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#a45c7f75393792069c8554aa5f0f215c1", null ],
    [ "getErrorMessage", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#aea5157fc9487152598e1ffcce3d5e740", null ],
    [ "getHTTPStatusCode", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#a89233d62e120fd531c292653c10359c5", null ],
    [ "VOOSMP_ERR_CLIENT", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#a0767b280cbadc51948aa0911fe91443e", null ],
    [ "VOOSMP_ERR_CONNECTION", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#aa2614bfd8ac52eecbb89aeef97c19663", null ],
    [ "VOOSMP_ERR_NONE", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#a4d20ed2f1ad71b85be902cb3a915a2e7", null ],
    [ "VOOSMP_ERR_SERVER", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#a0571eba5ebc56e838ef3328ff7bda272", null ],
    [ "VOOSMP_ERR_UNKNOWN", "d7/d3a/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_license_retriever.html#adfefe8c2d889ec2b236eeccebe1c02db", null ]
];