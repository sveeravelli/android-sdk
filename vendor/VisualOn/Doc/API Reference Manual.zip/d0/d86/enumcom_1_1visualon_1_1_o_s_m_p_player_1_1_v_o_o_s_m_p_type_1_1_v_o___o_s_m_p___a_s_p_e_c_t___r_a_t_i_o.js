var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o =
[
    [ "VO_OSMP_ASPECT_RATIO", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a00126f01a2bc9c9704c54f47dffaddc7", null ],
    [ "getValue", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a2cee8a57b3ea3883855caeb56b394f54", null ],
    [ "valueOf", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a98a32297787b8f11c5deed8e5f6ea47e", null ],
    [ "VO_OSMP_RATIO_00", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a41b63fd84b55e79be49e230799080819", null ],
    [ "VO_OSMP_RATIO_11", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a8e6f51038c3a4437234d3ff54f8aaa4b", null ],
    [ "VO_OSMP_RATIO_169", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a232600a121389f25aea84dc1d8a9b8e9", null ],
    [ "VO_OSMP_RATIO_21", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a9a48521108c3d7538dcab25326a508d9", null ],
    [ "VO_OSMP_RATIO_2331", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#ad8bc947d0ab6b2ca025dc02d13f8ad3d", null ],
    [ "VO_OSMP_RATIO_43", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#aa11619b26ddf815e6ec3820f3b879c79", null ],
    [ "VO_OSMP_RATIO_AUTO", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a3763f6382f58b97300c0fd86ba897dab", null ],
    [ "VO_OSMP_RATIO_MAX", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#ad05a34bb82bd92028ef0d94bc1e28b91", null ],
    [ "VO_OSMP_RATIO_ORIGINAL", "d0/d86/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___a_s_p_e_c_t___r_a_t_i_o.html#a991729bb91a847ea9222df7f11717ac0", null ]
];