var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s =
[
    [ "VO_OSMP_STATUS", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#a3774b331423f9293ded024c77620415d", null ],
    [ "getValue", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#affe35af433ab2885436663d747adfb25", null ],
    [ "valueOf", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#a65875fd95a3efd8888e1753244f3cf6f", null ],
    [ "VO_OSMP_STATUS_INITIALIZING", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#ac1f6a6498187492589cb26611f26405b", null ],
    [ "VO_OSMP_STATUS_LOADING", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#af74c1f49ae925ac38923ee2896de1a9e", null ],
    [ "VO_OSMP_STATUS_MAX", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#a90f186419edb8a5bd85753bffcbf1f35", null ],
    [ "VO_OSMP_STATUS_PAUSED", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#ab8fd2a8515111edee9872889a0a32cf6", null ],
    [ "VO_OSMP_STATUS_PLAYING", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#acb0bb33e30e25d5b2188b9a60402e364", null ],
    [ "VO_OSMP_STATUS_STOPPED", "d0/d14/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___s_t_a_t_u_s.html#a791c278525470afc43103f1ecc6e9ab7", null ]
];