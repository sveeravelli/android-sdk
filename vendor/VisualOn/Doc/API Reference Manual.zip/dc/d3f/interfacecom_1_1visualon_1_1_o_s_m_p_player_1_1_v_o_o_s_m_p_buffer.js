var interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_buffer =
[
    [ "getBuffer", "dc/d3f/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_buffer.html#a3b19f62a6d123f79b456a80e6754b016", null ],
    [ "getBufferSize", "dc/d3f/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_buffer.html#a292aa353b3341cc103f7490329c5ef97", null ],
    [ "getTimestamp", "dc/d3f/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_buffer.html#ab340e3082a2fffbe09099323136002ff", null ]
];