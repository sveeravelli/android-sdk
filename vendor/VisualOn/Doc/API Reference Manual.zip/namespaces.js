var namespaces =
[
    [ "com", "d8/dee/namespacecom.html", "d8/dee/namespacecom" ]
];