var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_y_o_u_t___t_y_p_e =
[
    [ "VO_OSMP_LAYOUT_TYPE", "d5/db6/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_y_o_u_t___t_y_p_e.html#a86e122d3d01c4f728fcbac1faeb09ff7", null ],
    [ "getValue", "d5/db6/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_y_o_u_t___t_y_p_e.html#a1f3704e40b6d90ac7d7e921df36ee2ae", null ],
    [ "VO_OSMP_LAYOUT_PHONE", "d5/db6/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_y_o_u_t___t_y_p_e.html#a103c1ee1ae1495656f912a92374425e6", null ],
    [ "VO_OSMP_LAYOUT_TABLET", "d5/db6/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_y_o_u_t___t_y_p_e.html#a025e033d5d9a34c1430b128276d5a92f", null ],
    [ "VO_OSMP_LAYOUT_TV", "d5/db6/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_y_o_u_t___t_y_p_e.html#a0d35f19011843b8ab0a5208c766e7a8c", null ]
];