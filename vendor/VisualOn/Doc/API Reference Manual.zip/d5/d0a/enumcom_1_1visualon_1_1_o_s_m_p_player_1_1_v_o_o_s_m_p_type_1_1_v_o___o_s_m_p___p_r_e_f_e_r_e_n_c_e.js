var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e =
[
    [ "VO_OSMP_PREFERENCE", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a8c8ce6a84054e66d4b50a5bac2eeec24", null ],
    [ "getValue", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#ac554da32df821c9f63a1efdc7c084c9e", null ],
    [ "valueOf", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a817a8e8f5392f55fddf90d907ddca7e2", null ],
    [ "VO_OSMP_PREF_MAX", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a2ecde5d1c757e127cdc0286067221d1d", null ],
    [ "VO_OSMP_PREF_NO_SEEK_PRECISE", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a1f7df359e0d6c76eb27b06e71c494750", null ],
    [ "VO_OSMP_PREF_NO_SELECT_AUDIO_SWITCH_IMMEDIATELY", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a6ae30a87dcb4a20240dea334a0e72c56", null ],
    [ "VO_OSMP_PREF_NO_STOP_KEEP_LAST_FRAME", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a65bb91a242ce48e69e1fc20e625a4e54", null ],
    [ "VO_OSMP_PREF_SEEK_PRECISE", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a5348fca8c8c02c3d30b60b9d1a4745e9", null ],
    [ "VO_OSMP_PREF_SELECT_AUDIO_SWITCH_IMMEDIATELY", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#ae82ae4e15d97ab2a8363a89736c180b4", null ],
    [ "VO_OSMP_PREF_STOP_KEEP_LAST_FRAME", "d5/d0a/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___p_r_e_f_e_r_e_n_c_e.html#a546743b072551af33bcdcc07fde91da7", null ]
];