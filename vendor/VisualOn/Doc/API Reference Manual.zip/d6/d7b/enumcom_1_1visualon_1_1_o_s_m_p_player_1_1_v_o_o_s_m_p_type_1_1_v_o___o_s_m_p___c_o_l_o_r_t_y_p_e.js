var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e =
[
    [ "VO_OSMP_COLORTYPE", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#ab8817153fc708ed45ab06e7ea8b31e53", null ],
    [ "getValue", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#af894e084dd9ec161722334a9afea48f0", null ],
    [ "valueOf", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#a5e82c8085a9970866e6f71fc04e80330", null ],
    [ "VO_OSMP_COLOR_ARGB32_PACKED", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#a96f9acf8700158d44c8215c99e762547", null ],
    [ "VO_OSMP_COLOR_MAX", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#a52d9d70d6db09597feea832e5d457be7", null ],
    [ "VO_OSMP_COLOR_RGB32_PACKED", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#ac2e2b5779f7eb14df4516402ffb42f85", null ],
    [ "VO_OSMP_COLOR_RGB565_PACKED", "d6/d7b/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___c_o_l_o_r_t_y_p_e.html#abd6520adb1a2e81bef582d13b47cd507", null ]
];