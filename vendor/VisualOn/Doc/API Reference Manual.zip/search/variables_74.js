var searchData=
[
  ['tag',['TAG',['../d3/d31/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_common_player_listener.html#a09d7f70773d82acbb6a24fe7cec3ff69',1,'com.visualon.OSMPPlayer.VOCommonPlayerListener.TAG()'],['../d3/d06/classcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type.html#a81b62ca14e2636fe78fb216bda42acda',1,'com.visualon.OSMPPlayer.VOOSMPType.TAG()']]]
];
