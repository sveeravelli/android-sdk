var searchData=
[
  ['playercallback',['PlayerCallback',['../d1/dd0/interfacecom_1_1visualon_1_1_o_s_m_p_player_impl_1_1_ad_vo_i_m_a_imp_1_1_i_i_m_a_player_1_1_player_callback.html',1,'com::visualon::OSMPPlayerImpl::AdVoIMAImp::IIMAPlayer']]]
];
