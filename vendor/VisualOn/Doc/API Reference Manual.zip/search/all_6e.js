var searchData=
[
  ['notifyplaynewvideo',['notifyPlayNewVideo',['../dc/d4f/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_ad_tracking.html#ac7fca02096b0b924893fc9f6d03720d1',1,'com::visualon::OSMPPlayer::VOOSMPAdTracking']]]
];
