var interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_h_t_t_p_download_failure =
[
    [ "VO_OSMP_HTTP_DOWNLOAD_FAILURE_REASON", "d4/db7/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_h_t_t_p_download_failure_1_1_v_o___o_s_m_4f7e48bbecbebd3bfdbe68cbf20c81b8.html", "d4/db7/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_h_t_t_p_download_failure_1_1_v_o___o_s_m_4f7e48bbecbebd3bfdbe68cbf20c81b8" ],
    [ "getReason", "d9/db8/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_h_t_t_p_download_failure.html#a21b0302df47fdabdb6413bd8772a6f98", null ],
    [ "getResponse", "d9/db8/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_h_t_t_p_download_failure.html#ae72b438e066cafb65fd826c555ca7456", null ],
    [ "getURL", "d9/db8/interfacecom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_h_t_t_p_download_failure.html#ae867c28780b268988287c5915b475c4d", null ]
];