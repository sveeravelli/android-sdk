var enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e =
[
    [ "VO_OSMP_LANGUAGE_TYPE", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#a5b52e9a86aca236d96e505abbd4b4e4d", null ],
    [ "getValue", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#a2050f798c0567f65b3f3529e88263921", null ],
    [ "valueOf", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#addbb14fb5ed21dca69870a3003d649e8", null ],
    [ "VO_OSMP_LANGUAGE_CHI", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#ae4ad5afbebd0257c515f4d1f9a62fdc9", null ],
    [ "VO_OSMP_LANGUAGE_ENG", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#af596d18f43e68d84e09ad79995eb5ab1", null ],
    [ "VO_OSMP_LANGUAGE_FRA", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#a10f85a64398e799927d6646501f4d39e", null ],
    [ "VO_OSMP_LANGUAGE_MAX", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#a6b3e56b8590215e257b35a6ec0c1e648", null ],
    [ "VO_OSMP_LANGUAGE_SWE", "d9/d1c/enumcom_1_1visualon_1_1_o_s_m_p_player_1_1_v_o_o_s_m_p_type_1_1_v_o___o_s_m_p___l_a_n_g_u_a_g_e___t_y_p_e.html#a155e0e59e65f7a6b1c454cd4d8ec75ea", null ]
];